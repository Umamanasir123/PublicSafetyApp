import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class Dim{
  static double screenHeight=Get.context!.height;    //683.42
  static double screenWidtht=Get.context!.width;     //411.42

  static double height5=screenHeight/136.684;
  static double height8=screenHeight/85.42;
  static double height10=screenHeight/68.342;
  static double height20=screenHeight/34.171;
  static double height15=screenHeight/45.56;
  static double height40=screenHeight/17.08;
  static double height200=screenHeight/3.417;
  static double height100=screenHeight/6.834;
  static double height25=screenHeight/27.33;
  static double height120=screenHeight/5.695;
  static double height175=screenHeight/3.9052;
  static double height210=screenHeight/3.254;
  static double HeightAppBar=screenHeight/3.5047;

  static double width180=screenHeight/3.796;
  static double width140=screenHeight/4.88;
  static double width15=screenHeight/45.56;
  static double width2=screenHeight/341.71;
  static double width5=screenHeight/136.68;
  static double width19=screenHeight/35.96;
  static double width150=screenHeight/4.556;
  static double width290=screenHeight/2.356;
  static double width400=screenHeight/1.7085;
  static double width412=screenHeight/1.6587;
  static double width10=screenHeight/68.24;
  static double width265=screenHeight/2.5789;
  static double widthMainAppBar=screenHeight/1.65878;

  static double font16=screenHeight/42.713;
  static double font30=screenHeight/22.780;
  static double font17=screenHeight/39.0525;     //for 17.5
  static double font19=screenHeight/35.969;     
  static double font15=screenHeight/44.09;       // for 15.5   
  static double font12=screenHeight/56.954;       // for 15.5   
  static double font13=screenHeight/56.954;       // for 15.5   
  static double font40=screenHeight/17.085;  

  static double m9=screenHeight/75.93; 
  static double m3=screenHeight/227.8; 
  static double m6=screenHeight/113.9;
  static double m10=screenHeight/68.34; 
  static double m12=screenHeight/56.95; 
  static double m16=screenHeight/42.71; 
  static double m22=screenHeight/31.063; 
  static double m4=screenHeight/170.85; 

static double height12=screenHeight/56.96;
  static double height150=screenHeight/4.5;
  static double height30=screenHeight/22.7;
  static double height250=screenHeight/2.7;

  static double height80=screenHeight/8.5;


  static double height300=screenHeight/2.27;
  static double height400=screenHeight/1.705;


  static double height70=screenHeight/9.75;
  static double height450=screenHeight/1.51;
  static double width380=screenHeight/1.79;


     







}

//logo image height