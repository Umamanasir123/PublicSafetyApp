package com.example.public_safety_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
